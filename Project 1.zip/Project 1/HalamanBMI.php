<?php
include_once 'header.php';
include_once 'sidebar.php';
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Project 1</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item"><a href="#">Layout</a></li>
              <li class="breadcrumb-item active">Fixed Layout</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- Default box -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Body Mass Index</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
              <div class="card-body">
              <?php
class bmiPasien {
    public  $tgl_pasien, 
            $nama,
            $berat,
            $tinggi,
            $umur,
            $jenisKelamin;
          
    public function hasilBMI() {
        return "<b>Tanggal Pasien : $this->tgl_pasien<br><br>
              Nama : $this->nama   <br><br>
              Tanggal Pasien : $this->tgl_pasien<br><br>
              Berat Badan : $this->berat <br><br>                  
              Tinggi Badan : $this->tinggi <br><br>
              Umur : $this->umur <br><br>
              Jenis Kelamin : $this->jenisKelamin</b>"; 
    }
    public function statusBMI($BMI) {
        if ($BMI < 18.5) {
            return "<td>Kekurangan Berat Badan</td>";
        }
        else if ($BMI >= 18.5 && $BMI <= 24.9) {
            return "<td>Normal (ideal)</td>";
        }
        else if ($BMI >= 25.0 && $BMI <= 29.9) {
            return "<td>Kelebihan Berat Badan</td>";
        }
        else {
            return "<td>Kegemukan (Obesitas)</td>";
        }
    }
  }
  if (isset($_GET["tgl_pasien"])) {
    $bmi = new bmiPasien;
    $bmi->kode_pasien = $_GET["kode_pasien"];
    $bmi->tgl_pasien = $_GET["tgl_pasien"];
    $bmi->nama = $_GET["nama__lengkap"];
    $bmi->berat = $_GET["berat__"];
    $bmi->tinggi = $_GET["tinggi__"];
    $bmi->umur = $_GET["umur__"];
    $bmi->jenisKelamin = $_GET["jenis__kelamin"];
  }
  $pasien1 = ['kode_pasien'=>'P001', 'tgl_pasien'=>$bmi->tgl_pasien, 'nama'=>'Renny Diaz', 'kelamin'=>'Perempuan', 'umur'=>31, 'berat'=>78.50, 'tinggi'=>169];
  $pasien2 = ['kode_pasien'=>'P002', 'tgl_pasien'=>$bmi->tgl_pasien, 'nama'=>'Revy Diaz', 'kelamin'=>'Perempuan', 'umur'=>29, 'berat'=>55.10, 'tinggi'=>160];
  $pasien3 = ['kode_pasien'=>'P003', 'tgl_pasien'=>$bmi->tgl_pasien, 'nama'=>'Rosy Diaz', 'kelamin'=>'Perempuan', 'umur'=>26, 'berat'=>43, 'tinggi'=>153];
  $pasien4 = ['kode_pasien'=>'P004', 'tgl_pasien'=>$bmi->tgl_pasien, 'nama'=>'Reva Diaz', 'kelamin'=>'Perempuan', 'umur'=>19, 'berat'=>45.50, 'tinggi'=>156];
  $pasien5 = ['kode_pasien'=>$bmi->kode_pasien, 'tgl_pasien'=>$bmi->tgl_pasien, 'nama'=>$bmi->nama, 'kelamin'=>$bmi->jenisKelamin, 'umur'=>$bmi->umur, 'berat'=>$bmi->berat, 'tinggi'=>$bmi->tinggi];

  $ar_pasien = [$pasien1, $pasien2, $pasien3, $pasien4, $pasien5];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
    <title>OUTPUT</title>
</head>
<body>
    <div class="container">
        <h2 class="text-center mb-5">Data BMI Pasien</h2>
        <table class="table table-hover table-striped">
            <thead>
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Kode Pasien</th>
                    <th scope="col">Tanggal Pasien</th>
                    <th scope="col">Nama Lengkap</th>
                    <th scope="col">Gender</th>
                    <th scope="col">Umur</th>
                    <th scope="col">Berat</th>
                    <th scope="col">Tinggi</th>
                    <th scope="col">BMI</th>
                    <th scope="col">Hasil</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                    $nomor = 1;
                    foreach($ar_pasien as $pasien) {
                        echo '<tr><td>'.$nomor.'</td>';
                        echo '<td>'.$pasien['kode_pasien'].'</td>';
                        echo '<td>'.$pasien['tgl_pasien'].'</td>';
                        echo '<td>'.$pasien['nama'].'</td>';
                        echo '<td>'.$pasien['kelamin'].'</td>';
                        echo '<td>'.$pasien['umur'].'</td>';
                        echo '<td>'.$pasien['berat'].'</td>';
                        echo '<td>'.$pasien['tinggi'].'</td>';
                        $BMI = $pasien["berat"] / (($pasien["tinggi"]/100)**2);
                        echo '<td>'.number_format($BMI,1).'</td>';
                        $status = new bmiPasien();
                        echo $status->statusBMI($BMI);
                        echo '</tr>';
                        $nomor++;
                    }
                ?>
            </tbody>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>
</body>
</html>
              </div>
              <!-- /.card-body -->
              <div class="card-footer">
                Selesai
              </div>
              <!-- /.card-footer-->
            </div>
            <!-- /.card -->
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>

<?php
include_once 'footer.php';
?>
